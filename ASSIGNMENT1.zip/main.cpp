#include <iostream>
using namespace std; 

int main() {
    // declare and initialize variables
    int A = 10;
    int B = 35;
    int C = A + B;
    
    // display the result
    cout << "Sum of " << A << " and " << B << " is: " << C << endl;
    
    return 0;
}